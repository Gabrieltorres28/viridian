"use client"

import { useRef, useEffect, useCallback } from "react"
import Image from "next/image"
import { ArrowRight, MessageCircle } from "lucide-react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

/* ─────────────────────────────────────────────
   Circuit-line SVG background overlay
   ───────────────────────────────────────────── */
function CircuitBackground() {
  return (
    <svg
      className="absolute inset-0 w-full h-full opacity-[0.06] pointer-events-none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <pattern
          id="circuit-lines"
          x="0"
          y="0"
          width="200"
          height="200"
          patternUnits="userSpaceOnUse"
        >
          {/* Horizontal traces */}
          <line x1="0" y1="40" x2="80" y2="40" stroke="#40826D" strokeWidth="0.5" />
          <line x1="120" y1="40" x2="200" y2="40" stroke="#40826D" strokeWidth="0.5" />
          <line x1="0" y1="120" x2="60" y2="120" stroke="#40826D" strokeWidth="0.5" />
          <line x1="140" y1="120" x2="200" y2="120" stroke="#40826D" strokeWidth="0.5" />
          {/* Vertical traces */}
          <line x1="80" y1="0" x2="80" y2="40" stroke="#40826D" strokeWidth="0.5" />
          <line x1="120" y1="40" x2="120" y2="80" stroke="#40826D" strokeWidth="0.5" />
          <line x1="60" y1="80" x2="60" y2="120" stroke="#40826D" strokeWidth="0.5" />
          <line x1="140" y1="120" x2="140" y2="160" stroke="#40826D" strokeWidth="0.5" />
          {/* Diagonal connectors */}
          <line x1="80" y1="40" x2="120" y2="40" stroke="#40826D" strokeWidth="0.5" strokeDasharray="4 4" />
          <line x1="60" y1="120" x2="140" y2="120" stroke="#40826D" strokeWidth="0.5" strokeDasharray="4 4" />
          {/* Junction dots */}
          <circle cx="80" cy="40" r="2" fill="#40826D" />
          <circle cx="120" cy="40" r="2" fill="#40826D" />
          <circle cx="60" cy="120" r="2" fill="#40826D" />
          <circle cx="140" cy="120" r="2" fill="#40826D" />
          <circle cx="80" cy="80" r="1.2" fill="#4eda9e" />
          <circle cx="160" cy="160" r="1.2" fill="#4eda9e" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#circuit-lines)" />
    </svg>
  )
}

/* ─────────────────────────────────────────────
   Main cinematic hero with GSAP pinned scroll
   ───────────────────────────────────────────── */
export function HeroCinematic() {
  /* Refs for GSAP targets */
  const wrapperRef = useRef<HTMLDivElement>(null)
  const heroRef = useRef<HTMLElement>(null)
  const eagleShadowRef = useRef<HTMLDivElement>(null)
  const eagleMainRef = useRef<HTMLDivElement>(null)
  const eagleGlowRef = useRef<HTMLDivElement>(null)
  const parallaxContainerRef = useRef<HTMLDivElement>(null)
  const line1Ref = useRef<HTMLSpanElement>(null)
  const line2Ref = useRef<HTMLSpanElement>(null)
  const subtextRef = useRef<HTMLParagraphElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)
  const tagRef = useRef<HTMLParagraphElement>(null)
  const glowBgRef = useRef<HTMLDivElement>(null)

  /* Desktop mouse-tilt parallax */
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!parallaxContainerRef.current || window.innerWidth < 768) return

    const { clientX, clientY } = e
    const centerX = window.innerWidth / 2
    const centerY = window.innerHeight / 2
    const offsetX = ((clientX - centerX) / centerX) * 8  // max 8deg
    const offsetY = ((clientY - centerY) / centerY) * 5  // max 5deg

    gsap.to(parallaxContainerRef.current, {
      rotateY: offsetX,
      rotateX: -offsetY,
      duration: 0.6,
      ease: "power2.out",
      overwrite: "auto",
    })
  }, [])

  useEffect(() => {
    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [handleMouseMove])

  /* GSAP ScrollTrigger timeline (pinned hero) */
  useEffect(() => {
    const ctx = gsap.context(() => {
      /* Initial states */
      gsap.set([line1Ref.current, line2Ref.current, subtextRef.current, ctaRef.current, tagRef.current], {
        opacity: 0,
        y: 40,
      })
      gsap.set(eagleShadowRef.current, {
        opacity: 0,
        x: 200,
        y: 40,
        scale: 0.7,
        rotateZ: 12,
      })
      gsap.set(eagleMainRef.current, {
        opacity: 0,
        x: 250,
        y: 30,
        scale: 0.75,
        rotateZ: 10,
        rotateY: -20,
      })
      gsap.set(eagleGlowRef.current, {
        opacity: 0,
        x: 300,
        y: 50,
        scale: 0.6,
      })
      gsap.set(glowBgRef.current, {
        opacity: 0.03,
      })

      /* Main pinned timeline */
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: wrapperRef.current,
          start: "top top",
          end: "+=250%",
          pin: heroRef.current,
          scrub: 1.2,
          anticipatePin: 1,
        },
      })

      /* Phase 1: Eagle enters + tag + headline line 1 (0% -> 35%) */
      tl.to(tagRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.08,
        ease: "power2.out",
      }, 0)

      // Eagle shadow (deepest layer, slowest)
      tl.to(eagleShadowRef.current, {
        opacity: 0.15,
        x: 0,
        y: 20,
        scale: 1.05,
        rotateZ: 2,
        duration: 0.35,
        ease: "power2.out",
      }, 0)

      // Eagle main (middle layer)
      tl.to(eagleMainRef.current, {
        opacity: 0.55,
        x: 0,
        y: 0,
        scale: 1,
        rotateZ: 0,
        rotateY: 0,
        duration: 0.35,
        ease: "power2.out",
      }, 0.02)

      // Eagle glow (front layer, fastest approach)
      tl.to(eagleGlowRef.current, {
        opacity: 0.35,
        x: -10,
        y: -10,
        scale: 1.1,
        duration: 0.35,
        ease: "power2.out",
      }, 0.04)

      // Headline line 1
      tl.to(line1Ref.current, {
        opacity: 1,
        y: 0,
        duration: 0.15,
        ease: "power2.out",
      }, 0.1)

      /* Phase 2: Eagle crosses + headline line 2 (35% -> 65%) */
      // Eagle continues to drift left with subtle rotation
      tl.to(eagleShadowRef.current, {
        x: -60,
        y: -10,
        rotateZ: -3,
        scale: 1.1,
        duration: 0.3,
      }, 0.35)

      tl.to(eagleMainRef.current, {
        x: -40,
        y: -20,
        rotateZ: -2,
        rotateY: 8,
        scale: 1.05,
        duration: 0.3,
      }, 0.37)

      tl.to(eagleGlowRef.current, {
        x: -70,
        y: -30,
        scale: 1.15,
        opacity: 0.45,
        duration: 0.3,
      }, 0.39)

      // Headline line 2 reveal
      tl.to(line2Ref.current, {
        opacity: 1,
        y: 0,
        duration: 0.15,
        ease: "power2.out",
      }, 0.4)

      /* Phase 3: Eagle settles near CTA, everything visible (65% -> 100%) */
      // Eagle settles down-left
      tl.to(eagleShadowRef.current, {
        x: -80,
        y: 30,
        rotateZ: -1,
        scale: 1.08,
        opacity: 0.1,
        duration: 0.35,
      }, 0.65)

      tl.to(eagleMainRef.current, {
        x: -60,
        y: 20,
        rotateZ: 0,
        rotateY: 5,
        scale: 1.02,
        opacity: 0.4,
        duration: 0.35,
      }, 0.65)

      tl.to(eagleGlowRef.current, {
        x: -90,
        y: 10,
        scale: 1.2,
        opacity: 0.3,
        duration: 0.35,
      }, 0.65)

      // Background glow intensifies
      tl.to(glowBgRef.current, {
        opacity: 0.1,
        duration: 0.35,
      }, 0.65)

      // Subtext + CTA reveal
      tl.to(subtextRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.15,
        ease: "power2.out",
      }, 0.7)

      tl.to(ctaRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.15,
        ease: "power2.out",
      }, 0.78)
    }, wrapperRef)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={wrapperRef}>
      <section
        ref={heroRef}
        className="relative h-screen w-full overflow-hidden bg-background"
        style={{ perspective: "1200px" }}
      >
        {/* === Background layers === */}

        {/* Circuit-line SVG pattern */}
        <CircuitBackground />

        {/* Soft radial viridian glow */}
        <div
          ref={glowBgRef}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] rounded-full pointer-events-none"
          style={{
            background:
              "radial-gradient(circle, var(--viridian-glow) 0%, var(--viridian) 30%, transparent 70%)",
          }}
        />

        {/* Subtle vignette edges */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse at center, transparent 40%, var(--background) 100%)",
          }}
        />

        {/* === Pseudo-3D Eagle Parallax Container === */}
        <div
          ref={parallaxContainerRef}
          className="absolute inset-0 pointer-events-none"
          style={{
            transformStyle: "preserve-3d",
            willChange: "transform",
          }}
        >
          {/* Layer A: Faint silhouette / shadow (deepest) */}
          <div
            ref={eagleShadowRef}
            className="absolute top-[5%] right-[-5%] w-[320px] h-[320px] md:w-[500px] md:h-[500px] lg:w-[620px] lg:h-[620px]"
            style={{
              transform: "translateZ(-120px)",
              filter: "blur(6px) brightness(0.3)",
              willChange: "transform, opacity",
            }}
          >
            <Image
              src="/images/eagle.jpg"
              alt=""
              fill
              className="object-contain mix-blend-lighten"
              priority
              sizes="(max-width: 768px) 320px, (max-width: 1024px) 500px, 620px"
            />
          </div>

          {/* Layer B: Main eagle image (middle) */}
          <div
            ref={eagleMainRef}
            className="absolute top-[5%] right-[-3%] w-[300px] h-[300px] md:w-[460px] md:h-[460px] lg:w-[580px] lg:h-[580px]"
            style={{
              transform: "translateZ(0px)",
              willChange: "transform, opacity",
            }}
          >
            <Image
              src="/images/eagle.jpg"
              alt="Viridian Core eagle"
              fill
              className="object-contain mix-blend-lighten"
              priority
              sizes="(max-width: 768px) 300px, (max-width: 1024px) 460px, 580px"
            />
          </div>

          {/* Layer C: Viridian glow + streaks (closest) */}
          <div
            ref={eagleGlowRef}
            className="absolute top-[3%] right-[-7%] w-[340px] h-[340px] md:w-[520px] md:h-[520px] lg:w-[650px] lg:h-[650px]"
            style={{
              transform: "translateZ(80px)",
              willChange: "transform, opacity",
            }}
          >
            {/* Glow behind eagle */}
            <div
              className="absolute inset-[15%] rounded-full"
              style={{
                background:
                  "radial-gradient(circle, rgba(78,218,158,0.25) 0%, rgba(64,130,109,0.1) 40%, transparent 70%)",
              }}
            />
            {/* Circuit streaks */}
            <svg
              className="absolute inset-0 w-full h-full opacity-40"
              viewBox="0 0 200 200"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <line x1="30" y1="80" x2="100" y2="60" stroke="#4eda9e" strokeWidth="0.5" strokeDasharray="6 8" />
              <line x1="50" y1="130" x2="120" y2="100" stroke="#40826D" strokeWidth="0.4" strokeDasharray="4 6" />
              <line x1="70" y1="50" x2="150" y2="70" stroke="#4eda9e" strokeWidth="0.3" strokeDasharray="3 5" />
              <line x1="90" y1="140" x2="170" y2="110" stroke="#40826D" strokeWidth="0.4" strokeDasharray="5 7" />
              <circle cx="100" cy="60" r="1.5" fill="#4eda9e" />
              <circle cx="120" cy="100" r="1" fill="#40826D" />
              <circle cx="150" cy="70" r="1.2" fill="#4eda9e" />
            </svg>
          </div>
        </div>

        {/* === Content === */}
        <div className="relative z-10 flex items-center justify-center h-full px-6">
          <div className="max-w-4xl mx-auto text-center">
            {/* Tag */}
            <p
              ref={tagRef}
              className="text-viridian font-mono text-sm tracking-[0.2em] uppercase mb-8"
            >
              Viridian Core
            </p>

            {/* Headline */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground leading-tight tracking-tight">
              <span ref={line1Ref} className="block text-balance">
                Tu negocio no necesita m&aacute;s esfuerzo.
              </span>
              <span ref={line2Ref} className="block text-viridian mt-2 text-balance">
                Necesita un sistema.
              </span>
            </h1>

            {/* Subtext */}
            <p
              ref={subtextRef}
              className="mt-8 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
            >
              Sistemas web de gesti&oacute;n para negocios en Argentina.
            </p>

            {/* CTAs */}
            <div
              ref={ctaRef}
              className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <a
                href="#demos"
                className="group flex items-center gap-2 bg-viridian text-foreground font-medium px-8 py-3.5 rounded-lg transition-all hover:shadow-[0_0_30px_rgba(64,130,109,0.35)]"
              >
                Ver demos
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href="https://wa.me/5491100000000"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 border border-border text-foreground font-medium px-8 py-3.5 rounded-lg transition-all hover:border-viridian hover:text-viridian"
              >
                <MessageCircle className="w-4 h-4" />
                Hablar por WhatsApp
              </a>
            </div>
          </div>
        </div>

        {/* Bottom fade to next section */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent pointer-events-none" />
      </section>
    </div>
  )
}

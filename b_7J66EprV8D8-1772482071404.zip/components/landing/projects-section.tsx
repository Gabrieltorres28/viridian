"use client"

import { motion } from "motion/react"
import { ExternalLink, Info } from "lucide-react"

const projects = [
  {
    name: "GymFlow",
    description:
      "Sistema integral para gimnasios: membresías, pagos, asistencia y métricas de retención.",
    tags: ["Next.js", "PostgreSQL", "Prisma"],
  },
  {
    name: "WorkshopOS",
    description:
      "Gestión de talleres mecánicos: turnos, presupuestos, seguimiento de reparaciones y facturación.",
    tags: ["Next.js", "PostgreSQL", "Tailwind"],
  },
  {
    name: "CoreCommerce",
    description:
      "Plataforma de e-commerce B2B con control de stock, precios por cliente y reportes de venta.",
    tags: ["Next.js", "Prisma", "Stripe"],
  },
  {
    name: "StudioPro",
    description:
      "Sistema para estudios contables: gestión de clientes, vencimientos, AFIP y facturación.",
    tags: ["Next.js", "PostgreSQL", "Auth"],
  },
  {
    name: "VetTrack",
    description:
      "Gestión veterinaria: historias clínicas, turnos, stock de medicamentos y recordatorios.",
    tags: ["Next.js", "PostgreSQL", "Prisma"],
  },
  {
    name: "RentaFlow",
    description:
      "Administración de propiedades: contratos, cobros automáticos, vencimientos y reportes.",
    tags: ["Next.js", "Prisma", "Cron"],
  },
]

export function ProjectsSection() {
  return (
    <section id="demos" className="relative py-32 px-6">
      {/* Subtle bg accent */}
      <div
        className="absolute bottom-0 right-0 w-[500px] h-[500px] opacity-[0.03]"
        style={{
          background:
            "radial-gradient(circle, var(--viridian-glow) 0%, transparent 70%)",
        }}
      />

      <div className="relative max-w-6xl mx-auto">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <p className="text-viridian font-mono text-sm tracking-[0.2em] uppercase mb-4">
            Portfolio
          </p>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground tracking-tight text-balance">
            {"Sistemas en acci\u00f3n"}
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, i) => (
            <motion.div
              key={project.name}
              className="group relative bg-card border border-border rounded-xl p-7 flex flex-col transition-all hover:border-viridian/40 hover:scale-[1.02]"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
            >
              {/* Hover glow */}
              <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" style={{
                background: "radial-gradient(ellipse at center, rgba(64,130,109,0.05) 0%, transparent 70%)"
              }} />

              <div className="relative flex flex-col flex-1">
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {project.name}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5 flex-1">
                  {project.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs font-mono text-viridian bg-viridian/10 px-2.5 py-1 rounded-md"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Buttons */}
                <div className="flex gap-3">
                  <button className="flex items-center gap-1.5 text-sm font-medium text-foreground bg-viridian/15 hover:bg-viridian/25 px-4 py-2 rounded-lg transition-colors">
                    <ExternalLink className="w-3.5 h-3.5" />
                    Ver demo
                  </button>
                  <button className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground border border-border hover:border-viridian/30 px-4 py-2 rounded-lg transition-all">
                    <Info className="w-3.5 h-3.5" />
                    {"M\u00e1s detalles"}
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

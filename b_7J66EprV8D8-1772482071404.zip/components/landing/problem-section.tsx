"use client"

import { motion } from "motion/react"
import { Users, CreditCard, Package, BarChart3 } from "lucide-react"

const cards = [
  {
    icon: Users,
    title: "Control de clientes",
    description:
      "Centralizá toda la información de tus clientes, historial de compras y contacto en un solo lugar.",
  },
  {
    icon: CreditCard,
    title: "Registro de pagos",
    description:
      "Llevá un registro claro de cobros, deudas y pagos pendientes sin planillas de Excel.",
  },
  {
    icon: Package,
    title: "Gestión de stock",
    description:
      "Controlá tu inventario en tiempo real con alertas de stock bajo y movimientos automáticos.",
  },
  {
    icon: BarChart3,
    title: "Reportes financieros claros",
    description:
      "Visualizá ingresos, egresos y márgenes con dashboards claros y accionables.",
  },
]

export function ProblemSection() {
  return (
    <section className="relative py-32 px-6">
      {/* Subtle radial accent */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] opacity-[0.04]"
        style={{
          background:
            "radial-gradient(ellipse, var(--viridian-glow) 0%, transparent 70%)",
        }}
      />

      <div className="relative max-w-6xl mx-auto">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <p className="text-viridian font-mono text-sm tracking-[0.2em] uppercase mb-4">
            El problema
          </p>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground tracking-tight text-balance">
            {"El problema no es tu negocio. "}
            <br className="hidden md:block" />
            {"Es la gesti\u00f3n."}
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {cards.map((card, i) => (
            <motion.div
              key={card.title}
              className="group relative bg-card border border-border rounded-xl p-8 transition-all hover:border-viridian/40"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
            >
              {/* Hover glow */}
              <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" style={{
                background: "radial-gradient(ellipse at center, rgba(64,130,109,0.06) 0%, transparent 70%)"
              }} />

              <div className="relative">
                <div className="w-12 h-12 rounded-lg bg-viridian/10 flex items-center justify-center mb-5">
                  <card.icon className="w-6 h-6 text-viridian" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  {card.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {card.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

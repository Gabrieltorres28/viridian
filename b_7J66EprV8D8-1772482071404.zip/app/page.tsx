import { Navbar } from "@/components/landing/navbar"
import { HeroCinematic } from "@/components/landing/hero-cinematic"
import { ProblemSection } from "@/components/landing/problem-section"
import { HowItWorksSection } from "@/components/landing/how-it-works-section"
import { ProjectsSection } from "@/components/landing/projects-section"
import { CtaSection } from "@/components/landing/cta-section"
import { Footer } from "@/components/landing/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <HeroCinematic />
      <div id="soluciones">
        <ProblemSection />
      </div>
      <div id="proceso">
        <HowItWorksSection />
      </div>
      <ProjectsSection />
      <div id="contacto">
        <CtaSection />
      </div>
      <Footer />
    </main>
  )
}
